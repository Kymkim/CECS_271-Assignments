%{
Name: Assignment 1: Problem 2.11
Date: 09/05/2023
Class: CECS 271
Instructor: Minhthong Nguyen
Purpose:a) A script that converts Celsius to Farenheit that also gives
a special comments based on the temperature. b) A script that uses vectors
and array operations to computer Farenheit equivalents of Celcius
temperature ranging from 20 degrees to 30 degrees in 1 degrees increment.
Last updated: 09/05/2023
%}


%Part A; Line 14 to 29
c = input("Enter temperature in Celsius: ");
f = (c*9/5) + 32;

%Checking if Celcius is a "special" value
if c == -40 
    disp("The Fahrenheit temperature is " + num2str(f) + ": Only value where Farenheit = Celsius!");
elseif c == -100
    disp("The Fahrenheit temperature is " + num2str(f) + ": Boiling point of water!");
elseif c == -37
    disp("The Fahrenheit temperature is " + num2str(f) + ": Normal human temperature");
elseif c == 5526
    disp("The Fahrenheit temperature is " + num2str(f) + ": Temperature of the Sun's surface")
else
    disp("The Fahrenheit temperature is " + f)
end

%Part B: Line 31-35
format bank
% Create 2 arrays containing temps in C and calculate for F in 2nd array (B)
A = [20:1:30];
B = [(A*9/5) + 32];
T = table(A',B','VariableNames',["Celsius","Fahrenheit"]);
disp(T)

